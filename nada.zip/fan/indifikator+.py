import math
while True:
    t = 2
    r = 0
    i = 0
    h = True
    k = int(input("введи K: "))
    n = int(input("введи N: "))
    while h:
        th = t ** r
        if th < n:
            r += 1
        else:
            i = r
            h = False
    ind = int(input("введи ind: "))
    bt = k*i
    d = bt/8
    v = math.ceil(d)*ind
    g = v/1024
    print("байт: ", v)
    print("килобайт: ", g)
    print()

## K - количество символов одного идентификатора;
## N - мощность алфавита;
## ind - количество идентификаторов
