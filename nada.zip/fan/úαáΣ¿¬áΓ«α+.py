while True:
    n = int(input("кол-во цветов в палитре: "))
    k1 = int(input("кол-во пикселей, значение №1:"))
    k2 = int(input("кол-во пикселей, значение №2:"))
    d = 0
    i = 0
    h = True
    while h:
        t = 2**d
        if t < n:
            d+=1
        else:
            i = d
            h = False
    g1 = (k1 * k2 * i) / 2 ** 3
    g2 = (k1 * k2 * i) / 2 ** 13
    g3 = (k1 * k2 * i) / 2 ** 23
    print("байт:", g1)
    print("килобайт:", g2)
    print("Мбайт:", g3)
    print()
